// Code goes here

(function(window, google) {
  
  var opciones = {
    center: {
      lat: 40.41677540,
      lng: -3.7037901999999576
    },
    zoom: 10
  },
  
  elemento=document.getElementById('map-canvas'),
  
  //mapa propiamente dicho
  
  map=new google.maps.Map(elemento, opciones);
  
} (window, google));
